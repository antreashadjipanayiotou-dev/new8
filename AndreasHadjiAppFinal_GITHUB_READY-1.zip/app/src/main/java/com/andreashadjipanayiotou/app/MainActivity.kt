package com.andreashadjipanayiotou.app

import android.content.Context
import android.content.Intent
import android.provider.OpenableColumns
import androidx.core.content.FileProvider
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Bg = Color(0xFF02060B)
private val Card = Color(0xFF07101A)
private val Card2 = Color(0xFF0A1420)
private val Gold = Color(0xFFFFC83D)
private val TextWhite = Color(0xFFF4F6FA)
private val Muted = Color(0xFFA7B8D8)

data class Demo(val id: Long, val title: String, val subtitle: String, val path: String)
data class Lyric(val id: Long, val title: String, val text: String)
data class Release(val id: Long, val title: String, val year: String, val url: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { AndreasApp() }
    }
}

@Composable
fun AndreasApp() {
    val context = LocalContext.current
    var tab by remember { mutableStateOf("Demos") }
    var admin by remember { mutableStateOf(false) }
    val store = remember { AppStore(context) }
    var demos by remember { mutableStateOf(store.demos()) }
    var lyrics by remember { mutableStateOf(store.lyrics()) }
    var releases by remember { mutableStateOf(store.releases()) }
    var bio by remember { mutableStateOf(store.bio()) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Bg, surface = Card, primary = Gold,
            onPrimary = Color(0xFF111111), onBackground = TextWhite,
            onSurface = TextWhite
        )
    ) {
        if (admin) {
            AdminScreen(
                store = store,
                demos = demos,
                lyrics = lyrics,
                releases = releases,
                bio = bio,
                onRefresh = {
                    demos = store.demos()
                    lyrics = store.lyrics()
                    releases = store.releases()
                    bio = store.bio()
                },
                onClose = { admin = false }
            )
        } else {
            HomeScreen(
                tab = tab,
                demos = demos,
                lyrics = lyrics,
                releases = releases,
                bio = bio,
                onTab = { tab = it },
                onAdmin = { admin = true }
            )
        }
    }
}

@Composable
private fun HomeScreen(
    tab: String, demos: List<Demo>, lyrics: List<Lyric>, releases: List<Release>,
    bio: String, onTab: (String) -> Unit, onAdmin: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().background(Bg),
        contentPadding = PaddingValues(bottom = 36.dp)
    ) {
        item { Hero(onAdmin) }
        item {
            NavigationTabs(tab, onTab)
        }
        item {
            Column(Modifier.padding(horizontal = 22.dp, vertical = 22.dp)) {
                when (tab) {
                    "Demos" -> DemosSection(demos)
                    "Στίχοι" -> LyricsSection(lyrics)
                    "Κυκλοφορίες" -> ReleasesSection(releases)
                    "Βιογραφικό" -> BioSection(bio)
                }
            }
        }
        item {
            Spacer(Modifier.height(8.dp))
            ContactBar()
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
private fun Hero(onAdmin: () -> Unit) {
    Box(
        Modifier.fillMaxWidth().height(430.dp)
    ) {
        Image(
            painter = painterResource(R.drawable.hero),
            contentDescription = "Andreas Hadjipanayiotou",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(
                    0f to Color.Transparent,
                    0.48f to Color.Transparent,
                    1f to Bg
                )
            )
        )
        Surface(
            modifier = Modifier.align(Alignment.TopEnd).padding(top = 46.dp, end = 16.dp)
                .clickable { onAdmin() },
            shape = RoundedCornerShape(32.dp),
            color = Color(0xE60B1521),
            border = BorderStroke(1.dp, Color(0xFF263750))
        ) {
            Row(Modifier.padding(horizontal = 18.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Settings, null, tint = Gold)
                Spacer(Modifier.width(8.dp))
                Text("Διαχείριση", fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            }
        }
        Column(
            Modifier.align(Alignment.BottomStart).padding(start = 22.dp, bottom = 20.dp)
        ) {
            Text("ANDREAS", fontSize = 38.sp, fontWeight = FontWeight.Black, color = TextWhite)
            Text("HADJIPANAYIOTOU", fontSize = 34.sp, fontWeight = FontWeight.Black, color = Gold)
            Spacer(Modifier.height(7.dp))
            Text(
                "Lyricist  •  Songwriter  •  Creator",
                fontSize = 17.sp, color = Muted, fontWeight = FontWeight.Medium
            )
            Spacer(Modifier.height(8.dp))
            Text(
                "Ανδρέας Χατζηπαναγιώτου",
                fontSize = 25.sp, color = Gold, fontStyle = FontStyle.Italic,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
private fun NavigationTabs(current: String, onTab: (String) -> Unit) {
    val tabs = listOf(
        Triple("Demos", Icons.Default.Headphones, "Demos"),
        Triple("Στίχοι", Icons.Default.EditNote, "Στίχοι"),
        Triple("Κυκλοφορίες", Icons.Default.MusicNote, "Κυκλοφορίες"),
        Triple("Βιογραφικό", Icons.Default.Person, "Βιογραφικό")
    )
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(9.dp)
    ) {
        tabs.forEach { (id, icon, label) ->
            val selected = current == id
            Surface(
                modifier = Modifier.weight(1f).height(92.dp).clickable { onTab(id) },
                shape = RoundedCornerShape(20.dp),
                color = if (selected) Gold else Card2,
                border = if (!selected) BorderStroke(1.dp, Color(0xFF263750)) else null
            ) {
                Column(
                    Modifier.fillMaxSize().padding(8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(icon, null, tint = if (selected) Color(0xFF0B0F14) else TextWhite, modifier = Modifier.size(31.dp))
                    Spacer(Modifier.height(5.dp))
                    Text(label, color = if (selected) Color(0xFF0B0F14) else TextWhite, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

@Composable
private fun DemosSection(demos: List<Demo>) {
    Text("🎧  Demos", fontSize = 30.sp, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(8.dp))
    Text("Ακούστε τα διαθέσιμα demos. Για ενδιαφέρον, πατήστε «Ενδιαφέρομαι».", color = Muted, fontSize = 16.sp, lineHeight = 23.sp)
    Spacer(Modifier.height(18.dp))
    if (demos.isEmpty()) {
        DemoCard(Demo(1, "Θεσσαλονίκη", "Νέο demo", ""), true)
    } else {
        demos.forEach { DemoCard(it, false) }
    }
}

@Composable
private fun DemoCard(demo: Demo, placeholder: Boolean) {
    val context = LocalContext.current
    var player by remember(demo.id) { mutableStateOf<MediaPlayer?>(null) }
    var playing by remember(demo.id) { mutableStateOf(false) }
    var progress by remember(demo.id) { mutableFloatStateOf(0f) }
    var duration by remember(demo.id) { mutableIntStateOf(0) }

    LaunchedEffect(playing, player) {
        while (playing && player != null) {
            val p = player ?: break
            if (p.duration > 0) progress = p.currentPosition.toFloat() / p.duration.toFloat()
            kotlinx.coroutines.delay(250)
        }
    }
    DisposableEffect(Unit) {
        onDispose { player?.release() }
    }

    Surface(
        modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
        shape = RoundedCornerShape(24.dp),
        color = Card,
        border = BorderStroke(1.dp, Color(0xFF263750))
    ) {
        Column(Modifier.padding(18.dp)) {
            Text(demo.title, fontSize = 25.sp, fontWeight = FontWeight.Bold)
            Text(demo.subtitle, color = Muted, fontSize = 16.sp)
            Spacer(Modifier.height(13.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                FilledIconButton(
                    onClick = {
                        if (placeholder || demo.path.isBlank()) return@FilledIconButton
                        if (player == null) {
                            player = MediaPlayer().apply {
                                setDataSource(context, Uri.fromFile(File(demo.path)))
                                prepare()
                                setOnCompletionListener {
                                    playing = false
                                    progress = 0f
                                }
                            }
                            duration = player?.duration ?: 0
                        }
                        if (playing) { player?.pause(); playing = false }
                        else { player?.start(); playing = true }
                    },
                    colors = IconButtonDefaults.filledIconButtonColors(containerColor = Gold),
                    modifier = Modifier.size(60.dp)
                ) {
                    Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Color.Black, modifier = Modifier.size(34.dp))
                }
                Spacer(Modifier.width(12.dp))
                Text(
                    if (duration > 0) "${formatTime((duration * progress).toInt())} / ${formatTime(duration)}" else "0:00",
                    color = Muted, fontSize = 15.sp
                )
            }
            Slider(
                value = progress,
                onValueChange = {
                    progress = it
                    player?.let { p -> if (p.duration > 0) p.seekTo((p.duration * it).toInt()) }
                },
                modifier = Modifier.fillMaxWidth(),
                colors = SliderDefaults.colors(thumbColor = TextWhite, activeTrackColor = Gold, inactiveTrackColor = Color(0xFF263750))
            )
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(
                    onClick = {
                        if (demo.path.isNotBlank()) {
                            val fileUri = FileProvider.getUriForFile(context, "${'$'}{context.packageName}.fileprovider", File(demo.path))
                            val intent = Intent(Intent.ACTION_VIEW).apply {
                                setDataAndType(fileUri, "audio/mpeg")
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            runCatching { context.startActivity(intent) }
                        }
                    },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Icon(Icons.Default.OpenInNew, null)
                    Spacer(Modifier.width(6.dp))
                    Text("Άνοιγμα ήχου")
                }
                Button(
                    onClick = {
                        val intent = Intent(Intent.ACTION_SENDTO).apply {
                            data = Uri.parse("mailto:")
                            putExtra(Intent.EXTRA_SUBJECT, "Ενδιαφέρομαι για το demo: ${demo.title}")
                        }
                        runCatching { context.startActivity(intent) }
                    },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color.Black),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Icon(Icons.Default.Email, null)
                    Spacer(Modifier.width(6.dp))
                    Text("Ενδιαφέρομαι", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun LyricsSection(items: List<Lyric>) {
    Text("✎  Στίχοι", fontSize = 30.sp, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(16.dp))
    if (items.isEmpty()) {
        EmptyCard("Δεν έχουν προστεθεί ακόμη στίχοι.")
    } else items.forEach {
        Surface(Modifier.fillMaxWidth().padding(bottom = 14.dp), shape = RoundedCornerShape(20.dp), color = Card, border = BorderStroke(1.dp, Color(0xFF263750))) {
            Column(Modifier.padding(18.dp)) {
                Text(it.title, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Gold)
                Spacer(Modifier.height(8.dp))
                Text(it.text, color = TextWhite, fontSize = 16.sp, lineHeight = 24.sp)
            }
        }
    }
}

@Composable
private fun ReleasesSection(items: List<Release>) {
    Text("♫  Κυκλοφορίες", fontSize = 30.sp, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(16.dp))
    if (items.isEmpty()) EmptyCard("Οι κυκλοφορίες σου θα εμφανίζονται εδώ.") else items.forEach {
        Surface(Modifier.fillMaxWidth().padding(bottom = 14.dp), shape = RoundedCornerShape(20.dp), color = Card, border = BorderStroke(1.dp, Color(0xFF263750))) {
            Column(Modifier.padding(18.dp)) {
                Text(it.title, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text(it.year, color = Muted)
                if (it.url.isNotBlank()) Text(it.url, color = Gold, modifier = Modifier.padding(top = 7.dp))
            }
        }
    }
}

@Composable
private fun BioSection(bio: String) {
    Text("●  Βιογραφικό", fontSize = 30.sp, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(16.dp))
    Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp), color = Card, border = BorderStroke(1.dp, Color(0xFF263750))) {
        Text(
            bio.ifBlank { "Πρόσθεσε το βιογραφικό σου από τη Διαχείριση." },
            modifier = Modifier.padding(20.dp), fontSize = 17.sp, lineHeight = 26.sp, color = TextWhite
        )
    }
}

@Composable
private fun EmptyCard(text: String) {
    Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), color = Card) {
        Text(text, Modifier.padding(20.dp), color = Muted, fontSize = 16.sp)
    }
}

@Composable
private fun ContactBar() {
    val context = LocalContext.current
    Surface(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 8.dp),
        shape = RoundedCornerShape(28.dp), color = Card, border = BorderStroke(1.dp, Color(0xFF263750))
    ) {
        Row(Modifier.fillMaxWidth().padding(7.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.ChatBubbleOutline, null, tint = TextWhite, modifier = Modifier.padding(10.dp))
            Text("Γράψε το μήνυμά σου...", color = Muted, modifier = Modifier.weight(1f), fontSize = 16.sp)
            FilledIconButton(
                onClick = {
                    val intent = Intent(Intent.ACTION_SENDTO).apply { data = Uri.parse("mailto:") }
                    runCatching { context.startActivity(intent) }
                },
                colors = IconButtonDefaults.filledIconButtonColors(containerColor = Gold)
            ) { Icon(Icons.Default.Send, null, tint = Color.Black) }
        }
    }
}

private fun displayName(context: Context, uri: Uri): String {
    var name = ""
    context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
        if (c.moveToFirst()) name = c.getString(0) ?: ""
    }
    return name.ifBlank { uri.lastPathSegment.orEmpty() }
}

private fun formatTime(ms: Int): String {
    val sec = (ms / 1000).coerceAtLeast(0)
    return "${sec / 60}:${(sec % 60).toString().padStart(2, '0')}"
}

@Composable
private fun AdminScreen(
    store: AppStore, demos: List<Demo>, lyrics: List<Lyric>, releases: List<Release>, bio: String,
    onRefresh: () -> Unit, onClose: () -> Unit
) {
    var unlocked by remember { mutableStateOf(false) }
    var pin by remember { mutableStateOf("") }
    var pinError by remember { mutableStateOf(false) }

    if (!unlocked) {
        Column(
            Modifier.fillMaxSize().background(Bg).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(Icons.Default.Settings, null, tint = Gold, modifier = Modifier.size(64.dp))
            Spacer(Modifier.height(12.dp))
            Text("Διαχείριση", fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Text("Βάλε το PIN διαχειριστή", color = Muted)
            Spacer(Modifier.height(18.dp))
            OutlinedTextField(
                value = pin, onValueChange = { pin = it; pinError = false },
                label = { Text("PIN") }, singleLine = true
            )
            if (pinError) Text("Λάθος PIN", color = MaterialTheme.colorScheme.error)
            Spacer(Modifier.height(14.dp))
            Button(onClick = { if (pin == store.pin()) unlocked = true else pinError = true },
                colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color.Black)) {
                Text("Είσοδος", fontWeight = FontWeight.Bold)
            }
            TextButton(onClick = onClose) { Text("Πίσω") }
            Spacer(Modifier.height(18.dp))
            Text("Προεπιλεγμένο PIN: 1234", color = Color(0xFF70809A), fontSize = 12.sp)
        }
        return
    }

    var showDemo by remember { mutableStateOf(false) }
    var showLyrics by remember { mutableStateOf(false) }
    var showRelease by remember { mutableStateOf(false) }
    var showBio by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().background(Bg)) {
        Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onClose) { Icon(Icons.Default.ArrowBack, null) }
            Text("Πίνακας Διαχείρισης", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                AdminAction("🎧", "Προσθήκη Demo MP3", "Διάλεξε MP3 απευθείας από το κινητό") { showDemo = true }
                AdminAction("✎", "Προσθήκη Στίχων", "Τίτλος και πλήρεις στίχοι") { showLyrics = true }
                AdminAction("♫", "Προσθήκη Κυκλοφορίας", "Τίτλος, έτος και σύνδεσμος") { showRelease = true }
                AdminAction("●", "Επεξεργασία Βιογραφικού", "Κείμενο ελληνικά ή αγγλικά") { showBio = true }
            }
            item {
                Text("Υπάρχοντα", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            }
            items(demos) { d ->
                AdminItem(d.title, "Demo MP3") {
                    store.deleteDemo(d.id); onRefresh()
                }
            }
            items(lyrics) { l ->
                AdminItem(l.title, "Στίχοι") {
                    store.deleteLyric(l.id); onRefresh()
                }
            }
            items(releases) { r ->
                AdminItem(r.title, "Κυκλοφορία") {
                    store.deleteRelease(r.id); onRefresh()
                }
            }
        }
    }

    if (showDemo) DemoDialog(store, { showDemo = false; onRefresh() })
    if (showLyrics) LyricsDialog(store, { showLyrics = false; onRefresh() })
    if (showRelease) ReleaseDialog(store, { showRelease = false; onRefresh() })
    if (showBio) BioDialog(store, bio, { showBio = false; onRefresh() })
}

@Composable
private fun AdminAction(icon: String, title: String, subtitle: String, action: () -> Unit) {
    Surface(Modifier.fillMaxWidth().clickable { action() }, shape = RoundedCornerShape(20.dp), color = Card, border = BorderStroke(1.dp, Color(0xFF263750))) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(icon, fontSize = 30.sp)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text(subtitle, color = Muted, fontSize = 14.sp)
            }
            Icon(Icons.Default.ChevronRight, null, tint = Gold)
        }
    }
}

@Composable
private fun AdminItem(title: String, subtitle: String, delete: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.SemiBold); Text(subtitle, color = Muted, fontSize = 12.sp) }
        IconButton(onClick = delete) { Icon(Icons.Default.DeleteOutline, null, tint = Color(0xFFFF8A8A)) }
    }
}

@Composable
private fun DemoDialog(store: AppStore, close: () -> Unit) {
    val context = LocalContext.current
    var title by remember { mutableStateOf("") }
    var subtitle by remember { mutableStateOf("Νέο demo") }
    var picked by remember { mutableStateOf<Uri?>(null) }
    var pickedName by remember { mutableStateOf("") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        picked = uri
        pickedName = uri?.let { displayName(context, it) }.orEmpty()
    }
    SimpleDialog("Νέο Demo", close) {
        OutlinedTextField(title, { title = it }, label = { Text("Τίτλος") }, singleLine = true)
        OutlinedTextField(subtitle, { subtitle = it }, label = { Text("Υπότιτλος") }, singleLine = true)
        Button(onClick = { picker.launch(arrayOf("audio/mpeg", "audio/*")) }, colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color.Black)) {
            Icon(Icons.Default.UploadFile, null); Spacer(Modifier.width(7.dp)); Text("Upload MP3 από το κινητό")
        }
        if (picked != null) {
            Text("Επιλεγμένο αρχείο: ${pickedName.ifBlank { "MP3" }}", color = Muted, fontSize = 13.sp)
        }
        Button(
            enabled = title.isNotBlank() && picked != null,
            onClick = {
                val path = store.copyAudio(context, picked!!)
                store.addDemo(title, subtitle, path)
                close()
            },
            colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color.Black)
        ) { Text("Αποθήκευση", fontWeight = FontWeight.Bold) }
    }
}

@Composable
private fun LyricsDialog(store: AppStore, close: () -> Unit) {
    var title by remember { mutableStateOf("") }
    var text by remember { mutableStateOf("") }
    SimpleDialog("Νέοι Στίχοι", close) {
        OutlinedTextField(title, { title = it }, label = { Text("Τίτλος") }, singleLine = true)
        OutlinedTextField(text, { text = it }, label = { Text("Στίχοι") }, minLines = 8)
        Button(enabled = title.isNotBlank() && text.isNotBlank(), onClick = { store.addLyric(title, text); close() },
            colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color.Black)) { Text("Αποθήκευση") }
    }
}

@Composable
private fun ReleaseDialog(store: AppStore, close: () -> Unit) {
    var title by remember { mutableStateOf("") }
    var year by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("") }
    SimpleDialog("Νέα Κυκλοφορία", close) {
        OutlinedTextField(title, { title = it }, label = { Text("Τίτλος") }, singleLine = true)
        OutlinedTextField(year, { year = it }, label = { Text("Έτος") }, singleLine = true)
        OutlinedTextField(url, { url = it }, label = { Text("Spotify / link (προαιρετικό)") }, singleLine = true)
        Button(enabled = title.isNotBlank(), onClick = { store.addRelease(title, year, url); close() },
            colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color.Black)) { Text("Αποθήκευση") }
    }
}

@Composable
private fun BioDialog(store: AppStore, current: String, close: () -> Unit) {
    var text by remember { mutableStateOf(current) }
    SimpleDialog("Βιογραφικό", close) {
        OutlinedTextField(text, { text = it }, label = { Text("Κείμενο") }, minLines = 10)
        Button(onClick = { store.setBio(text); close() }, colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color.Black)) {
            Text("Αποθήκευση")
        }
    }
}

@Composable
private fun SimpleDialog(title: String, close: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Dialog(onDismissRequest = close) {
        Surface(shape = RoundedCornerShape(24.dp), color = Card2, modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState())) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(title, Modifier.weight(1f), fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    IconButton(onClick = close) { Icon(Icons.Default.Close, null) }
                }
                content()
            }
        }
    }
}

class AppStore(private val context: Context) {
    private val prefs = context.getSharedPreferences("andreas_store", Context.MODE_PRIVATE)
    private val demoKey = "demos"; private val lyricKey = "lyrics"; private val releaseKey = "releases"

    fun pin() = prefs.getString("pin", "1234") ?: "1234"
    fun bio() = prefs.getString("bio", "") ?: ""

    fun setBio(value: String) = prefs.edit().putString("bio", value).apply()

    fun demos(): List<Demo> {
        val a = JSONArray(prefs.getString(demoKey, "[]"))
        return List(a.length()) { i -> a.getJSONObject(i).let { Demo(it.getLong("id"), it.getString("title"), it.getString("subtitle"), it.getString("path")) } }
    }
    fun lyrics(): List<Lyric> {
        val a = JSONArray(prefs.getString(lyricKey, "[]"))
        return List(a.length()) { i -> a.getJSONObject(i).let { Lyric(it.getLong("id"), it.getString("title"), it.getString("text")) } }
    }
    fun releases(): List<Release> {
        val a = JSONArray(prefs.getString(releaseKey, "[]"))
        return List(a.length()) { i -> a.getJSONObject(i).let { Release(it.getLong("id"), it.getString("title"), it.getString("year"), it.getString("url")) } }
    }

    fun addDemo(title: String, subtitle: String, path: String) {
        val list = demos().toMutableList()
        list.add(Demo(System.currentTimeMillis(), title, subtitle, path))
        val a = JSONArray(); list.forEach { a.put(JSONObject().apply { put("id", it.id); put("title", it.title); put("subtitle", it.subtitle); put("path", it.path) }) }
        prefs.edit().putString(demoKey, a.toString()).apply()
    }
    fun addLyric(title: String, text: String) {
        val list = lyrics().toMutableList(); list.add(Lyric(System.currentTimeMillis(), title, text))
        val a = JSONArray(); list.forEach { a.put(JSONObject().apply { put("id", it.id); put("title", it.title); put("text", it.text) }) }
        prefs.edit().putString(lyricKey, a.toString()).apply()
    }
    fun addRelease(title: String, year: String, url: String) {
        val list = releases().toMutableList(); list.add(Release(System.currentTimeMillis(), title, year, url))
        val a = JSONArray(); list.forEach { a.put(JSONObject().apply { put("id", it.id); put("title", it.title); put("year", it.year); put("url", it.url) }) }
        prefs.edit().putString(releaseKey, a.toString()).apply()
    }
    fun deleteDemo(id: Long) {
        val d = demos().firstOrNull { it.id == id }; d?.let { File(it.path).delete() }
        val a = JSONArray(); demos().filterNot { it.id == id }.forEach { a.put(JSONObject().apply { put("id", it.id); put("title", it.title); put("subtitle", it.subtitle); put("path", it.path) }) }
        prefs.edit().putString(demoKey, a.toString()).apply()
    }
    fun deleteLyric(id: Long) {
        val a = JSONArray(); lyrics().filterNot { it.id == id }.forEach { a.put(JSONObject().apply { put("id", it.id); put("title", it.title); put("text", it.text) }) }
        prefs.edit().putString(lyricKey, a.toString()).apply()
    }
    fun deleteRelease(id: Long) {
        val a = JSONArray(); releases().filterNot { it.id == id }.forEach { a.put(JSONObject().apply { put("id", it.id); put("title", it.title); put("year", it.year); put("url", it.url) }) }
        prefs.edit().putString(releaseKey, a.toString()).apply()
    }
    fun copyAudio(context: Context, uri: Uri): String {
        val dir = File(context.filesDir, "demos").apply { mkdirs() }
        val file = File(dir, "demo_${System.currentTimeMillis()}.mp3")
        context.contentResolver.openInputStream(uri)!!.use { input -> file.outputStream().use { output -> input.copyTo(output) } }
        return file.absolutePath
    }
}
